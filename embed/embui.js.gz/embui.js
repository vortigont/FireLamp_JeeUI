/**
 * @license
 * Lodash (Custom Build) lodash.com/license | Underscore.js 1.8.3 underscorejs.org/LICENSE
 * Build: `lodash include="at,get,find,findIndex,has,merge,mergeWith,set,unset"`
 */
;(function(){function t(t,e,n){switch(n.length){case 0:return t.call(e);case 1:return t.call(e,n[0]);case 2:return t.call(e,n[0],n[1]);case 3:return t.call(e,n[0],n[1],n[2])}return t.apply(e,n)}function e(t,e){for(var n=-1,r=null==t?0:t.length;++n<r&&false!==e(t[n],n,t););}function n(t,e){for(var n=-1,r=null==t?0:t.length,o=0,u=[];++n<r;){var c=t[n];e(c,n,t)&&(u[o++]=c)}return u}function r(t,e){for(var n=-1,r=e.length,o=t.length;++n<r;)t[o+n]=e[n];return t}function o(t,e){for(var n=-1,r=null==t?0:t.length;++n<r;)if(e(t[n],n,t))return true;
return false}function u(t){return function(e){return null==e?qt:e[t]}}function c(t){return function(e){return t(e)}}function i(t){var e=-1,n=Array(t.size);return t.forEach(function(t,r){n[++e]=[r,t]}),n}function a(t){var e=Object;return function(n){return t(e(n))}}function f(t){var e=-1,n=Array(t.size);return t.forEach(function(t){n[++e]=t}),n}function l(){}function s(t){var e=-1,n=null==t?0:t.length;for(this.clear();++e<n;){var r=t[e];this.set(r[0],r[1])}}function b(t){var e=-1,n=null==t?0:t.length;for(this.clear();++e<n;){
var r=t[e];this.set(r[0],r[1])}}function h(t){var e=-1,n=null==t?0:t.length;for(this.clear();++e<n;){var r=t[e];this.set(r[0],r[1])}}function p(t){var e=-1,n=null==t?0:t.length;for(this.__data__=new h;++e<n;)this.add(t[e])}function y(t){this.size=(this.__data__=new b(t)).size}function j(t,e){var n=jn(t),r=!n&&yn(t),o=!n&&!r&&_n(t),u=!n&&!r&&!o&&dn(t);if(n=n||r||o||u){for(var r=t.length,c=String,i=-1,a=Array(r);++i<r;)a[i]=c(i);r=a}else r=[];var f,c=r.length;for(f in t)!e&&!Oe.call(t,f)||n&&("length"==f||o&&("offset"==f||"parent"==f)||u&&("buffer"==f||"byteLength"==f||"byteOffset"==f)||st(f,c))||r.push(f);
return r}function _(t,e,n){(n===qt||wt(t[e],n))&&(n!==qt||e in t)||w(t,e,n)}function v(t,e,n){var r=t[e];Oe.call(t,e)&&wt(r,n)&&(n!==qt||e in t)||w(t,e,n)}function g(t,e){for(var n=t.length;n--;)if(wt(t[n][0],e))return n;return-1}function d(t,e){return t&&J(e,Lt(e),t)}function A(t,e){return t&&J(e,Nt(e),t)}function w(t,e,n){"__proto__"==e&&Ne?Ne(t,e,{configurable:true,enumerable:true,value:n,writable:true}):t[e]=n}function m(t,n,r,o,u,c){var i,a=1&n,f=2&n,l=4&n;if(r&&(i=u?r(t,o,u,c):r(t)),i!==qt)return i;
if(!zt(t))return t;if(o=jn(t)){if(i=it(t),!a)return H(t,i)}else{var s=sn(t),b="[object Function]"==s||"[object GeneratorFunction]"==s;if(_n(t))return W(t,a);if("[object Object]"==s||"[object Arguments]"==s||b&&!u){if(i=f||b?{}:at(t),!a)return f?Q(t,A(i,t)):K(t,d(i,t))}else{if(!ie[s])return u?t:{};i=ft(t,s,a)}}if(c||(c=new y),u=c.get(t))return u;if(c.set(t,i),gn(t))return t.forEach(function(e){i.add(m(e,n,r,e,t,c))}),i;if(vn(t))return t.forEach(function(e,o){i.set(o,m(e,n,r,o,t,c))}),i;var f=l?f?et:tt:f?Nt:Lt,h=o?qt:f(t);
return e(h||t,function(e,o){h&&(o=e,e=t[o]),v(i,o,m(e,n,r,o,t,c))}),i}function O(t,e,n,o,u){var c=-1,i=t.length;for(n||(n=lt),u||(u=[]);++c<i;){var a=t[c];0<e&&n(a)?1<e?O(a,e-1,n,o,u):r(u,a):o||(u[u.length]=a)}return u}function S(t,e){e=T(e,t);for(var n=0,r=e.length;null!=t&&n<r;)t=t[jt(e[n++])];return n&&n==r?t:qt}function k(t,e,n){return e=e(t),jn(t)?e:r(e,n(t))}function z(t){if(null==t)t=t===qt?"[object Undefined]":"[object Null]";else if(Le&&Le in Object(t)){var e=Oe.call(t,Le),n=t[Le];try{t[Le]=qt;
var r=true}catch(t){}var o=ke.call(t);r&&(e?t[Le]=n:delete t[Le]),t=o}else t=ke.call(t);return t}function x(t,e){return null!=t&&Oe.call(t,e)}function I(t,e){return null!=t&&e in Object(t)}function F(t){return xt(t)&&"[object Arguments]"==z(t)}function E(t,e,n,r,o){if(t===e)e=true;else if(null==t||null==e||!xt(t)&&!xt(e))e=t!==t&&e!==e;else t:{var u=jn(t),c=jn(e),i=u?"[object Array]":sn(t),a=c?"[object Array]":sn(e),i="[object Arguments]"==i?"[object Object]":i,a="[object Arguments]"==a?"[object Object]":a,f="[object Object]"==i,c="[object Object]"==a;
if((a=i==a)&&_n(t)){if(!_n(e)){e=false;break t}u=true,f=false}if(a&&!f)o||(o=new y),e=u||dn(t)?Y(t,e,n,r,E,o):Z(t,e,i,n,r,E,o);else{if(!(1&n)&&(u=f&&Oe.call(t,"__wrapped__"),i=c&&Oe.call(e,"__wrapped__"),u||i)){t=u?t.value():t,e=i?e.value():e,o||(o=new y),e=E(t,e,n,r,o);break t}if(a)e:if(o||(o=new y),u=1&n,i=tt(t),c=i.length,a=tt(e).length,c==a||u){for(f=c;f--;){var l=i[f];if(!(u?l in e:Oe.call(e,l))){e=false;break e}}if((a=o.get(t))&&o.get(e))e=a==e;else{a=true,o.set(t,e),o.set(e,t);for(var s=u;++f<c;){var l=i[f],b=t[l],h=e[l];
if(r)var p=u?r(h,b,l,e,t,o):r(b,h,l,t,e,o);if(p===qt?b!==h&&!E(b,h,n,r,o):!p){a=false;break}s||(s="constructor"==l)}a&&!s&&(n=t.constructor,r=e.constructor,n!=r&&"constructor"in t&&"constructor"in e&&!(typeof n=="function"&&n instanceof n&&typeof r=="function"&&r instanceof r)&&(a=false)),o.delete(t),o.delete(e),e=a}}else e=false;else e=false}}return e}function M(t){return xt(t)&&"[object Map]"==sn(t)}function $(t,e){var n=e.length,r=n;if(null==t)return!r;for(t=Object(t);n--;){var o=e[n];if(o[2]?o[1]!==t[o[0]]:!(o[0]in t))return false;
}for(;++n<r;){var o=e[n],u=o[0],c=t[u],i=o[1];if(o[2]){if(c===qt&&!(u in t))return false}else if(o=new y,void 0===qt?!E(i,c,3,void 0,o):1)return false}return true}function U(t){return xt(t)&&"[object Set]"==sn(t)}function B(t){return xt(t)&&kt(t.length)&&!!ce[z(t)]}function D(t){return typeof t=="function"?t:null==t?Vt:typeof t=="object"?jn(t)?L(t[0],t[1]):P(t):Tt(t)}function P(t){var e=ot(t);return 1==e.length&&e[0][2]?pt(e[0][0],e[0][1]):function(n){return n===t||$(n,e)}}function L(t,e){return bt(t)&&e===e&&!zt(e)?pt(jt(t),e):function(n){
var r=Dt(n,t);return r===qt&&r===e?Pt(n,t):E(e,r,3)}}function N(t,e,n,r,o){t!==e&&cn(e,function(u,c){if(zt(u)){o||(o=new y);var i=o,a="__proto__"==c?qt:t[c],f="__proto__"==c?qt:e[c],l=i.get(f);if(l)_(t,c,l);else{var l=r?r(a,f,c+"",t,e,i):qt,s=l===qt;if(s){var b=jn(f),h=!b&&_n(f),p=!b&&!h&&dn(f),l=f;b||h||p?jn(a)?l=a:Ot(a)?l=H(a):h?(s=false,l=W(f,true)):p?(s=false,l=q(f,true)):l=[]:It(f)||yn(f)?(l=a,yn(a)?l=Ut(a):(!zt(a)||n&&St(a))&&(l=at(f))):s=false}s&&(i.set(f,l),N(l,f,n,r,i),i.delete(f)),_(t,c,l)}}else i=r?r("__proto__"==c?qt:t[c],u,c+"",t,e,o):qt,
i===qt&&(i=u),_(t,c,i)},Nt)}function C(t){return function(e){return S(e,t)}}function V(t){return bn(yt(t,void 0,Vt),t+"")}function R(t){if(typeof t=="string")return t;if(jn(t)){for(var e=R,n=-1,r=null==t?0:t.length,o=Array(r);++n<r;)o[n]=e(t[n],n,t);return o+""}return Ft(t)?on?on.call(t):"":(e=t+"","0"==e&&1/t==-Ht?"-0":e)}function T(t,e){return jn(t)?t:bt(t,e)?[t]:hn(Bt(t))}function W(t,e){if(e)return t.slice();var n=t.length,n=Me?Me(n):new t.constructor(n);return t.copy(n),n}function G(t){var e=new t.constructor(t.byteLength);
return new Ee(e).set(new Ee(t)),e}function q(t,e){return new t.constructor(e?G(t.buffer):t.buffer,t.byteOffset,t.length)}function H(t,e){var n=-1,r=t.length;for(e||(e=Array(r));++n<r;)e[n]=t[n];return e}function J(t,e,n){var r=!n;n||(n={});for(var o=-1,u=e.length;++o<u;){var c=e[o],i=qt;i===qt&&(i=t[c]),r?w(n,c,i):v(n,c,i)}return n}function K(t,e){return J(t,fn(t),e)}function Q(t,e){return J(t,ln(t),e)}function X(t){return V(function(e,n){var r,o=-1,u=n.length,c=1<u?n[u-1]:qt,i=2<u?n[2]:qt,c=3<t.length&&typeof c=="function"?(u--,
c):qt;if(r=i){r=n[0];var a=n[1];if(zt(i)){var f=typeof a;r=!!("number"==f?mt(i)&&st(a,i.length):"string"==f&&a in i)&&wt(i[a],r)}else r=false}for(r&&(c=3>u?qt:c,u=1),e=Object(e);++o<u;)(i=n[o])&&t(e,i,o,c);return e})}function Y(t,e,n,r,u,c){var i=1&n,a=t.length,f=e.length;if(a!=f&&!(i&&f>a))return false;if((f=c.get(t))&&c.get(e))return f==e;var f=-1,l=true,s=2&n?new p:qt;for(c.set(t,e),c.set(e,t);++f<a;){var b=t[f],h=e[f];if(r)var y=i?r(h,b,f,e,t,c):r(b,h,f,t,e,c);if(y!==qt){if(y)continue;l=false;break}if(s){
if(!o(e,function(t,e){if(!s.has(e)&&(b===t||u(b,t,n,r,c)))return s.push(e)})){l=false;break}}else if(b!==h&&!u(b,h,n,r,c)){l=false;break}}return c.delete(t),c.delete(e),l}function Z(t,e,n,r,o,u,c){switch(n){case"[object DataView]":if(t.byteLength!=e.byteLength||t.byteOffset!=e.byteOffset)break;t=t.buffer,e=e.buffer;case"[object ArrayBuffer]":if(t.byteLength!=e.byteLength||!u(new Ee(t),new Ee(e)))break;return true;case"[object Boolean]":case"[object Date]":case"[object Number]":return wt(+t,+e);case"[object Error]":
return t.name==e.name&&t.message==e.message;case"[object RegExp]":case"[object String]":return t==e+"";case"[object Map]":var a=i;case"[object Set]":if(a||(a=f),t.size!=e.size&&!(1&r))break;return(n=c.get(t))?n==e:(r|=2,c.set(t,e),e=Y(a(t),a(e),r,o,u,c),c.delete(t),e);case"[object Symbol]":if(rn)return rn.call(t)==rn.call(e)}return false}function tt(t){return k(t,Lt,fn)}function et(t){return k(t,Nt,ln)}function nt(){var t=l.iteratee||Rt,t=t===Rt?D:t;return arguments.length?t(arguments[0],arguments[1]):t;
}function rt(t,e){var n=t.__data__,r=typeof e;return("string"==r||"number"==r||"symbol"==r||"boolean"==r?"__proto__"!==e:null===e)?n[typeof e=="string"?"string":"hash"]:n.map}function ot(t){for(var e=Lt(t),n=e.length;n--;){var r=e[n],o=t[r];e[n]=[r,o,o===o&&!zt(o)]}return e}function ut(t,e){var n=null==t?qt:t[e];return(!zt(n)||Se&&Se in n?0:(St(n)?xe:re).test(_t(n)))?n:qt}function ct(t,e,n){e=T(e,t);for(var r=-1,o=e.length,u=false;++r<o;){var c=jt(e[r]);if(!(u=null!=t&&n(t,c)))break;t=t[c]}return u||++r!=o?u:(o=null==t?0:t.length,
!!o&&kt(o)&&st(c,o)&&(jn(t)||yn(t)))}function it(t){var e=t.length,n=new t.constructor(e);return e&&"string"==typeof t[0]&&Oe.call(t,"index")&&(n.index=t.index,n.input=t.input),n}function at(t){return typeof t.constructor!="function"||ht(t)?{}:un($e(t))}function ft(t,e,n){var r=t.constructor;switch(e){case"[object ArrayBuffer]":return G(t);case"[object Boolean]":case"[object Date]":return new r(+t);case"[object DataView]":return e=n?G(t.buffer):t.buffer,new t.constructor(e,t.byteOffset,t.byteLength);
case"[object Float32Array]":case"[object Float64Array]":case"[object Int8Array]":case"[object Int16Array]":case"[object Int32Array]":case"[object Uint8Array]":case"[object Uint8ClampedArray]":case"[object Uint16Array]":case"[object Uint32Array]":return q(t,n);case"[object Map]":return new r;case"[object Number]":case"[object String]":return new r(t);case"[object RegExp]":return e=new t.constructor(t.source,te.exec(t)),e.lastIndex=t.lastIndex,e;case"[object Set]":return new r;case"[object Symbol]":
return rn?Object(rn.call(t)):{}}}function lt(t){return jn(t)||yn(t)||!!(Pe&&t&&t[Pe])}function st(t,e){var n=typeof t;return e=null==e?9007199254740991:e,!!e&&("number"==n||"symbol"!=n&&ue.test(t))&&-1<t&&0==t%1&&t<e}function bt(t,e){if(jn(t))return false;var n=typeof t;return!("number"!=n&&"symbol"!=n&&"boolean"!=n&&null!=t&&!Ft(t))||(Qt.test(t)||!Kt.test(t)||null!=e&&t in Object(e))}function ht(t){var e=t&&t.constructor;return t===(typeof e=="function"&&e.prototype||Ae)}function pt(t,e){return function(n){
return null!=n&&(n[t]===e&&(e!==qt||t in Object(n)))}}function yt(e,n,r){return n=Te(n===qt?e.length-1:n,0),function(){for(var o=arguments,u=-1,c=Te(o.length-n,0),i=Array(c);++u<c;)i[u]=o[n+u];for(u=-1,c=Array(n+1);++u<n;)c[u]=o[u];return c[n]=r(i),t(e,this,c)}}function jt(t){if(typeof t=="string"||Ft(t))return t;var e=t+"";return"0"==e&&1/t==-Ht?"-0":e}function _t(t){if(null!=t){try{return me.call(t)}catch(t){}return t+""}return""}function vt(t,e,n){var r=null==t?0:t.length;if(!r)return-1;n=null==n?0:Mt(n),
0>n&&(n=Te(r+n,0));t:{for(e=nt(e,3),r=t.length,n+=-1;++n<r;)if(e(t[n],n,t)){t=n;break t}t=-1}return t}function gt(t){return(null==t?0:t.length)?O(t,1):[]}function dt(t){var e=null==t?0:t.length;return e?t[e-1]:qt}function At(t,e){function n(){var r=arguments,o=e?e.apply(this,r):r[0],u=n.cache;return u.has(o)?u.get(o):(r=t.apply(this,r),n.cache=u.set(o,r)||u,r)}if(typeof t!="function"||null!=e&&typeof e!="function")throw new TypeError("Expected a function");return n.cache=new(At.Cache||h),n}function wt(t,e){
return t===e||t!==t&&e!==e}function mt(t){return null!=t&&kt(t.length)&&!St(t)}function Ot(t){return xt(t)&&mt(t)}function St(t){return!!zt(t)&&(t=z(t),"[object Function]"==t||"[object GeneratorFunction]"==t||"[object AsyncFunction]"==t||"[object Proxy]"==t)}function kt(t){return typeof t=="number"&&-1<t&&0==t%1&&9007199254740991>=t}function zt(t){var e=typeof t;return null!=t&&("object"==e||"function"==e)}function xt(t){return null!=t&&typeof t=="object"}function It(t){return!(!xt(t)||"[object Object]"!=z(t))&&(t=$e(t),
null===t||(t=Oe.call(t,"constructor")&&t.constructor,typeof t=="function"&&t instanceof t&&me.call(t)==ze))}function Ft(t){return typeof t=="symbol"||xt(t)&&"[object Symbol]"==z(t)}function Et(t){return t?(t=$t(t),t===Ht||t===-Ht?1.7976931348623157e308*(0>t?-1:1):t===t?t:0):0===t?t:0}function Mt(t){t=Et(t);var e=t%1;return t===t?e?t-e:t:0}function $t(t){if(typeof t=="number")return t;if(Ft(t))return Jt;if(zt(t)&&(t=typeof t.valueOf=="function"?t.valueOf():t,t=zt(t)?t+"":t),typeof t!="string")return 0===t?t:+t;
t=t.replace(Yt,"");var e=ne.test(t);return e||oe.test(t)?fe(t.slice(2),e?2:8):ee.test(t)?Jt:+t}function Ut(t){return J(t,Nt(t))}function Bt(t){return null==t?"":R(t)}function Dt(t,e,n){return t=null==t?qt:S(t,e),t===qt?n:t}function Pt(t,e){return null!=t&&ct(t,e,I)}function Lt(t){if(mt(t))t=j(t);else if(ht(t)){var e,n=[];for(e in Object(t))Oe.call(t,e)&&"constructor"!=e&&n.push(e);t=n}else t=Re(t);return t}function Nt(t){if(mt(t))t=j(t,true);else if(zt(t)){var e,n=ht(t),r=[];for(e in t)("constructor"!=e||!n&&Oe.call(t,e))&&r.push(e);
t=r}else{if(e=[],null!=t)for(n in Object(t))e.push(n);t=e}return t}function Ct(t){return function(){return t}}function Vt(t){return t}function Rt(t){return D(typeof t=="function"?t:m(t,1))}function Tt(t){return bt(t)?u(jt(t)):C(t)}function Wt(){return[]}function Gt(){return false}var qt,Ht=1/0,Jt=NaN,Kt=/\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,Qt=/^\w*$/,Xt=/[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,Yt=/^\s+|\s+$/g,Zt=/\\(\\)?/g,te=/\w*$/,ee=/^[-+]0x[0-9a-f]+$/i,ne=/^0b[01]+$/i,re=/^\[object .+?Constructor\]$/,oe=/^0o[0-7]+$/i,ue=/^(?:0|[1-9]\d*)$/,ce={};
ce["[object Float32Array]"]=ce["[object Float64Array]"]=ce["[object Int8Array]"]=ce["[object Int16Array]"]=ce["[object Int32Array]"]=ce["[object Uint8Array]"]=ce["[object Uint8ClampedArray]"]=ce["[object Uint16Array]"]=ce["[object Uint32Array]"]=true,ce["[object Arguments]"]=ce["[object Array]"]=ce["[object ArrayBuffer]"]=ce["[object Boolean]"]=ce["[object DataView]"]=ce["[object Date]"]=ce["[object Error]"]=ce["[object Function]"]=ce["[object Map]"]=ce["[object Number]"]=ce["[object Object]"]=ce["[object RegExp]"]=ce["[object Set]"]=ce["[object String]"]=ce["[object WeakMap]"]=false;
var ie={};ie["[object Arguments]"]=ie["[object Array]"]=ie["[object ArrayBuffer]"]=ie["[object DataView]"]=ie["[object Boolean]"]=ie["[object Date]"]=ie["[object Float32Array]"]=ie["[object Float64Array]"]=ie["[object Int8Array]"]=ie["[object Int16Array]"]=ie["[object Int32Array]"]=ie["[object Map]"]=ie["[object Number]"]=ie["[object Object]"]=ie["[object RegExp]"]=ie["[object Set]"]=ie["[object String]"]=ie["[object Symbol]"]=ie["[object Uint8Array]"]=ie["[object Uint8ClampedArray]"]=ie["[object Uint16Array]"]=ie["[object Uint32Array]"]=true,
ie["[object Error]"]=ie["[object Function]"]=ie["[object WeakMap]"]=false;var ae,fe=parseInt,le=typeof global=="object"&&global&&global.Object===Object&&global,se=typeof self=="object"&&self&&self.Object===Object&&self,be=le||se||Function("return this")(),he=typeof exports=="object"&&exports&&!exports.nodeType&&exports,pe=he&&typeof module=="object"&&module&&!module.nodeType&&module,ye=pe&&pe.exports===he,je=ye&&le.process;t:{try{ae=je&&je.binding&&je.binding("util");break t}catch(t){}ae=void 0}var _e=ae&&ae.isMap,ve=ae&&ae.isSet,ge=ae&&ae.isTypedArray,de=Array.prototype,Ae=Object.prototype,we=be["__core-js_shared__"],me=Function.prototype.toString,Oe=Ae.hasOwnProperty,Se=function(){
var t=/[^.]+$/.exec(we&&we.keys&&we.keys.IE_PROTO||"");return t?"Symbol(src)_1."+t:""}(),ke=Ae.toString,ze=me.call(Object),xe=RegExp("^"+me.call(Oe).replace(/[\\^$.*+?()[\]{}|]/g,"\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,"$1.*?")+"$"),Ie=ye?be.Buffer:qt,Fe=be.Symbol,Ee=be.Uint8Array,Me=Ie?Ie.a:qt,$e=a(Object.getPrototypeOf),Ue=Object.create,Be=Ae.propertyIsEnumerable,De=de.splice,Pe=Fe?Fe.isConcatSpreadable:qt,Le=Fe?Fe.toStringTag:qt,Ne=function(){try{var t=ut(Object,"defineProperty");
return t({},"",{}),t}catch(t){}}(),Ce=Object.getOwnPropertySymbols,Ve=Ie?Ie.isBuffer:qt,Re=a(Object.keys),Te=Math.max,We=Date.now,Ge=ut(be,"DataView"),qe=ut(be,"Map"),He=ut(be,"Promise"),Je=ut(be,"Set"),Ke=ut(be,"WeakMap"),Qe=ut(Object,"create"),Xe=_t(Ge),Ye=_t(qe),Ze=_t(He),tn=_t(Je),en=_t(Ke),nn=Fe?Fe.prototype:qt,rn=nn?nn.valueOf:qt,on=nn?nn.toString:qt,un=function(){function t(){}return function(e){return zt(e)?Ue?Ue(e):(t.prototype=e,e=new t,t.prototype=qt,e):{}}}();s.prototype.clear=function(){
this.__data__=Qe?Qe(null):{},this.size=0},s.prototype.delete=function(t){return t=this.has(t)&&delete this.__data__[t],this.size-=t?1:0,t},s.prototype.get=function(t){var e=this.__data__;return Qe?(t=e[t],"__lodash_hash_undefined__"===t?qt:t):Oe.call(e,t)?e[t]:qt},s.prototype.has=function(t){var e=this.__data__;return Qe?e[t]!==qt:Oe.call(e,t)},s.prototype.set=function(t,e){var n=this.__data__;return this.size+=this.has(t)?0:1,n[t]=Qe&&e===qt?"__lodash_hash_undefined__":e,this},b.prototype.clear=function(){
this.__data__=[],this.size=0},b.prototype.delete=function(t){var e=this.__data__;return t=g(e,t),!(0>t)&&(t==e.length-1?e.pop():De.call(e,t,1),--this.size,true)},b.prototype.get=function(t){var e=this.__data__;return t=g(e,t),0>t?qt:e[t][1]},b.prototype.has=function(t){return-1<g(this.__data__,t)},b.prototype.set=function(t,e){var n=this.__data__,r=g(n,t);return 0>r?(++this.size,n.push([t,e])):n[r][1]=e,this},h.prototype.clear=function(){this.size=0,this.__data__={hash:new s,map:new(qe||b),string:new s
}},h.prototype.delete=function(t){return t=rt(this,t).delete(t),this.size-=t?1:0,t},h.prototype.get=function(t){return rt(this,t).get(t)},h.prototype.has=function(t){return rt(this,t).has(t)},h.prototype.set=function(t,e){var n=rt(this,t),r=n.size;return n.set(t,e),this.size+=n.size==r?0:1,this},p.prototype.add=p.prototype.push=function(t){return this.__data__.set(t,"__lodash_hash_undefined__"),this},p.prototype.has=function(t){return this.__data__.has(t)},y.prototype.clear=function(){this.__data__=new b,
this.size=0},y.prototype.delete=function(t){var e=this.__data__;return t=e.delete(t),this.size=e.size,t},y.prototype.get=function(t){return this.__data__.get(t)},y.prototype.has=function(t){return this.__data__.has(t)},y.prototype.set=function(t,e){var n=this.__data__;if(n instanceof b){var r=n.__data__;if(!qe||199>r.length)return r.push([t,e]),this.size=++n.size,this;n=this.__data__=new h(r)}return n.set(t,e),this.size=n.size,this};var cn=function(t){return function(e,n,r){var o=-1,u=Object(e);r=r(e);
for(var c=r.length;c--;){var i=r[t?c:++o];if(false===n(u[i],i,u))break}return e}}(),an=Ne?function(t,e){return Ne(t,"toString",{configurable:true,enumerable:false,value:Ct(e),writable:true})}:Vt,fn=Ce?function(t){return null==t?[]:(t=Object(t),n(Ce(t),function(e){return Be.call(t,e)}))}:Wt,ln=Ce?function(t){for(var e=[];t;)r(e,fn(t)),t=$e(t);return e}:Wt,sn=z;(Ge&&"[object DataView]"!=sn(new Ge(new ArrayBuffer(1)))||qe&&"[object Map]"!=sn(new qe)||He&&"[object Promise]"!=sn(He.resolve())||Je&&"[object Set]"!=sn(new Je)||Ke&&"[object WeakMap]"!=sn(new Ke))&&(sn=function(t){
var e=z(t);if(t=(t="[object Object]"==e?t.constructor:qt)?_t(t):"")switch(t){case Xe:return"[object DataView]";case Ye:return"[object Map]";case Ze:return"[object Promise]";case tn:return"[object Set]";case en:return"[object WeakMap]"}return e});var bn=function(t){var e=0,n=0;return function(){var r=We(),o=16-(r-n);if(n=r,0<o){if(800<=++e)return arguments[0]}else e=0;return t.apply(qt,arguments)}}(an),hn=function(t){t=At(t,function(t){return 500===e.size&&e.clear(),t});var e=t.cache;return t}(function(t){
var e=[];return 46===t.charCodeAt(0)&&e.push(""),t.replace(Xt,function(t,n,r,o){e.push(r?o.replace(Zt,"$1"):n||t)}),e}),pn=function(t){return function(e,n,r){var o=Object(e);if(!mt(e)){var u=nt(n,3);e=Lt(e),n=function(t){return u(o[t],t,o)}}return n=t(e,n,r),-1<n?o[u?e[n]:n]:qt}}(vt);At.Cache=h;var yn=F(function(){return arguments}())?F:function(t){return xt(t)&&Oe.call(t,"callee")&&!Be.call(t,"callee")},jn=Array.isArray,_n=Ve||Gt,vn=_e?c(_e):M,gn=ve?c(ve):U,dn=ge?c(ge):B,An=function(t){return bn(yt(t,qt,gt),t+"");
}(function(t,e){for(var n=-1,r=e.length,o=Array(r),u=null==t;++n<r;)o[n]=u?qt:Dt(t,e[n]);return o}),wn=X(function(t,e,n){N(t,e,n)}),mn=X(function(t,e,n,r){N(t,e,n,r)});l.at=An,l.constant=Ct,l.flatten=gt,l.iteratee=Rt,l.keys=Lt,l.keysIn=Nt,l.memoize=At,l.merge=wn,l.mergeWith=mn,l.property=Tt,l.set=function(t,e,n){if(null!=t&&zt(t)){e=T(e,t);for(var r=-1,o=e.length,u=o-1,c=t;null!=c&&++r<o;){var i=jt(e[r]),a=n;if(r!=u){var f=c[i],a=qt;a===qt&&(a=zt(f)?f:st(e[r+1])?[]:{})}v(c,i,a),c=c[i]}}return t},
l.toPlainObject=Ut,l.unset=function(t,e){var n;if(null==t)n=true;else{var r=t,o=n=T(e,r);if(!(2>o.length)){var u=0,c=-1,i=-1,a=o.length;for(0>u&&(u=-u>a?0:a+u),c=c>a?a:c,0>c&&(c+=a),a=u>c?0:c-u>>>0,u>>>=0,c=Array(a);++i<a;)c[i]=o[i+u];r=S(r,c)}n=null==r||delete r[jt(dt(n))]}return n},l.eq=wt,l.find=pn,l.findIndex=vt,l.get=Dt,l.has=function(t,e){return null!=t&&ct(t,e,x)},l.hasIn=Pt,l.identity=Vt,l.isArguments=yn,l.isArray=jn,l.isArrayLike=mt,l.isArrayLikeObject=Ot,l.isBuffer=_n,l.isFunction=St,l.isLength=kt,
l.isMap=vn,l.isObject=zt,l.isObjectLike=xt,l.isPlainObject=It,l.isSet=gn,l.isSymbol=Ft,l.isTypedArray=dn,l.last=dt,l.stubArray=Wt,l.stubFalse=Gt,l.toFinite=Et,l.toInteger=Mt,l.toNumber=$t,l.toString=Bt,l.VERSION="4.17.5",typeof define=="function"&&typeof define.amd=="object"&&define.amd?(be._=l, define(function(){return l})):pe?((pe.exports=l)._=l,he._=l):be._=l}).call(this);var go = function(param, context){
  if (!arguments.length) return new GO(document);
  if (typeof param == "string") return (new GO(context || document)).go(param);
  if (typeof param == "undefined") return new GO();
  return new GO(param);
}

// process form data before serializing and sending to backend
go.formdata = function(form){
  var controls = {},
  chkNumeric = function(element){
    return isFinite(element.value) ? Number(element.value) : element.value;
  },
  checkValue = function(element){
    switch (element.type.toLowerCase()){
      case 'password':
        return element.value;    // keep password field value as-is string
      case 'checkbox':        // use boolean true/false as a value for 'checked' boxes  
        return element.checked;
      case 'number':
      case 'select-one':
      case 'range':
      case 'hidden':
        return chkNumeric(element);
      case 'radio':
        if(element.checked) return chkNumeric(element);
      case 'input':
      case 'textarea':
        return (typeof element.value == 'string' && element.value == "") ? null : this.value;
      default:
        return element.value;
    }
  };

  for(let i = 0; i < form.length; i++){
    let el = form[i];
    if (el.disabled) continue;
    switch (el.tagName.toLowerCase()){
      case 'input':
        var val = checkValue(el);
        if (typeof val != "undefined") controls[el.name || el.id] = val;
        break;
      case 'select':
        controls[el.name || el.id]= chkNumeric(el);
        break;
      //case 'textarea':
      default:
        continue;
    }
  }
  return controls;
}

go.linker = function(fn,th){
  var arg = Array.prototype.slice.call(arguments,2);
  return function(){ return fn.apply(th, Array.prototype.slice.call(arguments).concat(arg)); };
}
go.listevent = function(el, evn, fn, opt){
  var self = ((opt instanceof Object)? opt.self : 0) || this;
  el = (el instanceof Array)? el : [el];
  evn = (evn instanceof Array)? evn : [evn];
  var rfn = function(arg){
    return function(e){
      e = e || event;
      var a = arg.slice(); a.unshift(e);
      var retval = fn.apply(self, a);
      if (typeof retval !== 'undefined' && !retval){
        if(e.preventDefault) e.preventDefault();
        else e.returnValue = false;

        if(e.stopPropagation) e.stopPropagation();
        else e.cancelBubble = true;
      }
      return retval;
    };
  }([].slice.call(arguments,4));

  for(var i = 0; i < el.length; i++) for(var j = 0; j < evn.length; j++){
    if(window.addEventListener){
      el[i].addEventListener(evn[j], rfn, opt);
    }else{
      el[i].attachEvent("on"+evn[j], rfn);
    }
  }
};
go.path = function(el, p, st){
  p = (p instanceof Array)? p : p.split(".");
  var i = p.shift();
  if (!i && st && st._parent) return this.path(st._parent._this, p, st._parent);
  if (i == "_this" || i == "_this2" || i == "_this3") {
    return p.length? this.path(st._this, p, st) : el;
  }
  if (i == "_index") return st._index;
  if (i == "_key") return st._key;
  if (i == "_val") return st._val;

  if (!el) return el;
  if (el[i] instanceof Object && p.length) return this.path(el[i], p, st);
  return el[i];
}
// merge data coming in sepparate frames
go.merge = function(base, data, idx) {
  for (var i in data) {
    var id = idx? idx + parseInt(i) : i;
    if (typeof data[i] == 'object') {
      if (typeof base[id] != 'object') base[id] = (data[i] instanceof Array)? [] : {};
      this.merge(base[id], data[i], (i == "block") ? data.idx : undefined);
    } else base[id] = data[i];
  }
  //console.log("merged base", JSON.parse( JSON.stringify(base) ))
  return base;
}
go.eval = function(th, data) {
  return (function(){ return eval(data); }).call(th);
}

var GO = function(context){
  if (context) {
    context = ((context instanceof Object || typeof context == 'object') &&
      typeof context.length !== 'undefined' && context.nodeType == undefined
    )? context : [context];
    for(var i = 0; i < context.length; i++) this.push(context[i]);
  }
}
GO.prototype = new Array();
;(function($_){
  $_._alias = {},
  $_.alias = function(alias){
    for(var a in alias){
      $_[a] = function(path){
        path = (typeof path == 'string')? path.split(".") : path;
        return function(){
          var m = null, out = new GO([]);
          for (var i = 0; i < this.length; i++) {
            if (typeof path == 'function') {
              m = path.apply(this[i], arguments);
            } else {
              var obj = this[i], len = path.length - 1;
              for (var j = 0; obj && j < len; j++) obj = obj[path[j]];
              if (obj && typeof obj[path[len]] !== 'undefined') {
                if (typeof obj[path[len]] == 'function' || typeof obj[path[len]].toString == 'undefined'){
                  m = obj[path[len]].apply(obj, arguments);
                } else if (typeof obj[path[len]] == 'object'){
                  if (arguments.length == 2) obj[path[len]][arguments[0]] = arguments[1];
                  m = this[i];//obj[path[len]];
                } else {
                  if (arguments.length == 1) obj[path[len]] = arguments[0];
                  m = this[i];//obj[path[len]];
                }
              }
            }
            if (m === null) continue;
            if (m === undefined) m = this[i];
            if (!m || typeof m === 'string' || typeof m === 'function' || typeof m.length === 'undefined') {
              m = [m];
            }
            for (var n = 0; n < m.length; n++) out.push(m[n]);
          }
          return out;
        };
      }(alias[a]);
      $_._alias[a] = alias[a];
    }
    return this;
  }
  $_.alias({
    'go':'querySelectorAll',
    'query':'querySelectorAll',
    'attr':'getAttribute','sattr':'setAttribute','rattr':'removeAttribute',
    'byid':'getElementById',
    'bytag':'getElementsByTagName',
    'byname':'getElementsByName',
    'byclass':'getElementsByClassName',
    'css':'style',
    'style':'style',
    'display':'style.display',
    'left': 'style.left', 'right': 'style.right', 'top': 'style.top', 'bottom': 'style.bottom',
    'height': 'style.height', 'width': 'style.width',
    'innerHTML': 'innerHTML', 'src': 'src', 'href': 'href',
    'addClass':'classList.add', 'removeClass':'classList.remove', 'className':'className',
    'toggleClass':'classList.toggle', 'contClass':'classList.contains',
    'each': function(fn){
      var r = fn.apply(this, [].slice.call(arguments,1));
      return (typeof r != 'undefined')? r : this;
    },
    'exec': function(){ return this.apply(arguments); },
    'event': function(n,dt,ps) {
      var evt = null;
      ps = ps || {bubbles: false, cancelable: true, detail: undefined, view: undefined};
      ps.detail = dt;
      if (typeof window.CustomEvent != "function") {
        evt = document.createEvent('CustomEvent');
        evt.initCustomEvent(n, ps.bubbles, ps.cancelable, ps.detail);
      } else {
        evt = new CustomEvent(n, ps);
      }
      this.dispatchEvent(evt);
      return this;
    },
    'bind': function(ev, fn){
      return go.listevent.apply(this, [this, ev, fn, {self: this}].concat([].slice.call(arguments, 2)));
    },
    'find': function(k,v){
      return (typeof this == 'object' && this[k] && (!v || this[k] === v))? this : null;
    },
    'id': function(v){
      return (typeof this == 'object' && this["id"] === v)? this : null;
    },
    'set': function(k,v){
      if (typeof this == 'object') {
        if (typeof k == 'object') {
          for (var i in k) this[i] = k[i];
        } else this[k] = v;
        return this;
      }
      return null;
    },
    'cstyle': function(ps){
      if (typeof ps == 'object') for (var i in ps) {
        var st = i.split("-");
        for (var n = 1; n < st.length; n++) st[n] = st[n][0].toUpperCase() + st[n].slice(1);
        this.style[st.join("")] = ps[i];
      }
      return [window.getComputedStyle? window.getComputedStyle(this, (typeof ps == 'string')? ps : "") : this.currentStyle];
    },
    'showhide': function(){
      if (!this.style.display) this.style.display = go(this).cstyle()[0].display;
      this.style.display = (this.style.display === "none")? "block" : "none";
      return this;
    },
    'clone': function(){ return this.cloneNode(true); },
    'fragment': function(el){ return document.createDocumentFragment();  },
    'remove': function(){ var p = this.parentNode; p.removeChild(this); return this; },
    'clear': function(){ while(this.firstChild) this.removeChild(this.firstChild); return this; },
    'append': function(el){
      el = (el instanceof Array)? el : [el];
      for(var i = 0; i < el.length; i++) this.appendChild(el[i]);
      return this;
    },
    'prepend': function(el){
      el = (el instanceof Array)? el : [el];
      for(var i =  el.length; i > 0; i--) this.insertBefore(el[i-1], this.firstChild);
      return this;
    },
    'replace': function(el){
      el = (el instanceof Array)? el : [el];
      for(var i = 0; i < el.length; i++) {
        this.parentNode.insertBefore(el[i], this);
        if (i == el.length - 1) this.parentNode.removeChild(this);
      }
      return this;
    },
    'before': function(el){
      el = (el instanceof Array)? el : [el];
      for(var i =  el.length; i > 0; i--) this.parentNode.insertBefore(el[i-1], this);
      return this;
    },
    'after': function(el, t){
      el = (el instanceof Array)? el : [el];
      var ns = t? this.nextSibling : this.nextElementSibling;
      if (ns) {
        for(var i = el.length; i > 0; i--) this.parentNode.insertBefore(el[i-1], ns);
      } else {
        for(var i = 0; i < el.length; i++) this.parentNode.appendChild(el[i]);
      }
      return this;
    },
    'create': function(tg,a1,a2){
      tg = document.createElement(tg);
      var dt = (typeof a2 == "string")? a2 : ((typeof a1 == "string")? a1 : 0),
      at = (typeof a1 == "object")? a1 : 0;
      if(dt) tg.innerHTML = dt;
      if(at) for(var i in at) tg.setAttribute(i, at[i]);
      if (this !== document) this.appendChild(tg);
      return tg;
    },
    'html': function(vl,ap){ if(ap) this.innerHTML += vl; else this.innerHTML = vl; return this; },
    'children': function(){ return this.children; },
    'nodes': function(type){
      return (this.nodeType == (type? type : 1))? this : null;
    }
  });
}(GO.prototype));

var mustache = function(tmpl,func){
  this.nevent = 0; this.scope = [];
  this._tmpl = (typeof tmpl == 'string')? tmpl : tmpl.innerHTML.replace(/[\r\t\n]/g, "");
  this._func = func || this._func || {};

  this._func.exec = this._func.exec || function(d,fn){
    var arg = [].slice.call(arguments, 2),
    out = 'data-musfun'+this.nevent+'="'+fn+'" '+
    'data-musarg'+this.nevent+'="'+escape(JSON.stringify(arg))+'"';
    this.nevent++;
    return out;
  };
  this._func.onevent = this._func.onevent || function(d){
    var arg = [].slice.call(arguments, 1);
    arg.unshift(d, "event");
    return this._func.exec.apply(this, arg);
  };
  this._func.event = this._func.event || function(th,ev,fn){
    var arg = [].slice.call(arguments, 3);
    fn = th._func[fn];
    if (fn) go.listevent(this, ev.split(","), function(e){
      var a = arg.slice(); a.unshift(e); return fn.apply(this, a);
    }, {self: this});
  };
  this._func.if = this._func.if || function(d){
    for (var i = 1; i < arguments.length; i++) if (!arguments[i]) return 0;
    return 1;
  };
  this._func.if2 = this._func.if,
  this._func.if3 = this._func.if,
  this._func.calc = this._func.calc || function(d){
    return [].slice.call(arguments, 1).join();
  };
}
;(function($_){
  var cont = document.createElement("div"),
  rgobj = /\{\{(@|#|!|\^)([a-z0-9_.]+?)(?:\s+(.+?))?\}\}([\s\S]*?)\{\{\/\2\}\}/gi,
  rgitem = /\{\{(!|>)?([a-z0-9_.]+?)(?:\s+(.+?))?\}\}/gi,
  rgparam = /\s*,\s*/gi,
  rgfield = /[a-z0-9_.]+|".*?"|'.*?'|`.*?`/gi,
  strcon = ['true','false','null','undefined','typeof','instanceof','Array','Object'];

  $_._parse_param = function(val, data, stack){
    var m = val.match(rgfield), s = val.split(rgfield), out = "";
    while (s && (val = s.shift()) != undefined) {
      out += val;
      if (m && (val = m.shift())) {
        if (strcon.indexOf(val) != -1 || val[0] == '"' || val[0] == "'" || Number(val) == Number(val)) out += val;
        else if (val[0] == "`") out += val.substr(1, val.length - 2);
        else {
          this.scope.push(go.path(data, val, stack));
          out += "this["+(this.scope.length-1)+"]";
        }
      }
    }
    try{ return go.eval(this.scope, out); }catch(e){ return undefined; }
  }
  $_._parse_item = function(tmpl, data, stack){
    tmpl = (tmpl || "").replace(rgitem, go.linker(function(all, pref, name, argum){
      var arg = argum? argum.split(rgparam) : [], out;
      for (var i = 0; i < arg.length; i++) arg[i] = this._parse_param(arg[i], data, stack);
      if (pref == "!") return "";
      if (pref == ">"){
        var el = document.getElementById(name), dt = arg.length? arg[0] : data;
        return el? (new mustache(el, this._func)).parse(dt, this, stack) : "";
      }
      if (this._func[name]) {
        arg.unshift(data);
        return this._func[name].apply(this, arg);
      }
      out = go.path(data, name, stack);
      // treat undef/null values as empty string ""
      if (typeof out == 'undefined' || typeof out == 'object')
        return "";

      return out;
    }, this));
    return tmpl;
  }
  $_._parse_obj = function(tmpl, data, stack){
    tmpl = (tmpl || "").replace(rgobj, go.linker(function(all, pref, name, argum, body){
      var out = body || argum || "", value = go.path(data, name, stack);
      if (pref == "!") return "";
      if (typeof value == 'function' || this._func[name]) {
        var arg = (body && argum)? argum.split(rgparam) : [];
        for (var i = 0; i < arg.length; i++) arg[i] = this._parse_param(arg[i], data, stack);
        arg.unshift(data);
        if (pref == "@") arg.unshift(body);
        var res = (this._func[name] || value).apply(this, arg);
        if (pref == "#") out = res? this._parse_obj(out, data, stack) : "";
        else if (pref == "^") out = res? "" : this._parse_obj(out, data, stack);
        else out = res;
      } else if (value instanceof Array) {
        if (pref != "^" && !value.length) return "";
        if (pref == "^" && value.length) return "";
        var res = "", stk = {_this:data, _parent:stack};
        for (var i = 0; i < value.length; i++) {
          stk._index = i; stk._val = value[i];
          var tmp = this._parse_obj(out, value[i], stk);
          res += this._parse_item(tmp, value[i], stk);
        }
        out = res;
      } else if (value instanceof Object) {
        if (!value && pref == "#" || value && pref == "^") return "";
        var stk = {_this:data, _parent:stack};
        if (pref == "#" || pref == "^") {
          out = this._parse_obj(out, value, stk);
          out = this._parse_item(out, value, stk);
        } else {
          var res = "", n = 0;
          for (var i in value) {
            stk._index = n++; stk._key = i;
            var tmp = this._parse_obj(out, value[i], stk);
            res += this._parse_item(tmp, value[i], stk);
          }
          out = res;
        }
      } else {
        if (!value && pref == "#" || value && pref == "^") return "";
        out = this._parse_obj(out, data, stack);
        out = this._parse_item(out, data, stack);
      }

      return out;
    }, this));
    return tmpl;
  }
  $_.parse = function(data, parent, stack){
    this.nevent = (typeof parent == "object")? parent.nevent : 0;
    stack = stack || {_this:data};
    var out = this._parse_obj(this._tmpl, data, stack);
    out = this._parse_item(out, data, stack);
    if (parent) {
      if (typeof parent == "object") parent.nevent = this.nevent;
      return out;
    }
    cont.innerHTML = out;
    for (var i = 0; i <= this.nevent; i++){
      go("[data-musfun"+i+"]",cont).each(function(th){
        var fn = th._func[this.getAttribute("data-musfun"+i)],
        arg = JSON.parse(unescape(this.getAttribute("data-musarg"+i)));
        this.removeAttribute("data-musarg"+i);
        this.removeAttribute("data-musfun"+i);
        try{ if (fn){ arg.unshift(th); fn.apply(this, arg); } }catch(e){}
      }, this);
    }
    return [].slice.call(cont.childNodes);
  }
}(mustache.prototype));

var wbs = function(url){
  var ws = null, frame = {}, connected = false, lastmsg = null, to = null,
  open = function(fnopen, fnerror){
    ws = new WebSocket(url);
    ws.onerror = function(err){
      console.log("WS Error", err);
      if (fnerror) fnerror(err);
      if (typeof out.onerror== "function") {
        try{ out.onerror(); } catch(e){ console.log('Error onerror', e); }
      }
    }
    ws.onopen = function(){
      console.log("WS Open");
      if (fnopen) fnopen();
      if (typeof out.onopen== "function") {
        try{ out.onopen(); } catch(e){ console.log('Error onopen', e); }
      }
    },
    ws.onclose = function(){
      console.log("WS Close");
      if (typeof out.onclose== "function") {
        try{ out.onclose(); } catch(e){ console.log('Error onclose', e); }
      }
    }
    ws.onmessage = function(msg){
      let m = {};
      try{ m = JSON.parse(msg.data); } catch(e){ console.log('Error message', e); return; }
      //console.log('Received message:', msg.data);
      if (!(m instanceof Object)) return;
      if (m.section && !(m.section in frame) && m.final){
        receiv_msg(m);
        return;
      }
      if (m.section) {
        if (!frame[m.section]) frame[m.section] = {};
        go.merge(frame[m.section], m);
        if (m.final) {
          receiv_msg(frame[m.section]);
          delete frame[m.section];
        }
      } else {
        receiv_msg(m);
      }
    }
  },
  receiv_msg = function(msg){
    console.log('Received packet:', JSON.parse(JSON.stringify(msg)));
    if (msg.pkg && typeof out["on"+msg.pkg] == "function"){
      try{ out["on"+msg.pkg](msg); } catch(e){ console.log('Error on'+msg.pkg, e); }
    } else {
      try{ out["onUnknown"](msg); } catch(e){ console.log('Error on'+msg.pkg, e); }
    }
  },
  send = function(msg){ try{ ws.send(msg); }catch(e){} },
  send_msg = function(msg){
    console.log('Sending message:', msg);
    try{ lastmsg = JSON.stringify(msg); } catch(e){ console.log('Error stringify', e); return; }
    if (ws.readyState === WebSocket.OPEN){
      send(lastmsg);
      lastmsg = null;
    }
  },

  out = {
    connect: function(){
      console.log("WS Connect");
      ws = null;
      if (to) clearTimeout(to);
      to = setTimeout(function(){open(function(){
        to = null;
        if (lastmsg){ send(lastmsg); lastmsg = null; }
      })}, 500);
    },
    send_post: function(id, dt){
      send_msg({pkg:"post", action:id, data:dt});
    }
  };
  return out;
}

// ==============================
// DyncCSS
function changeCSS(cssFile, cssLinkIndex) {

    var oldlink = document.getElementsByTagName("link").item(cssLinkIndex);

    var newlink = document.createElement("link");
    newlink.setAttribute("rel", "stylesheet");
    newlink.setAttribute("type", "text/css");
    newlink.setAttribute("href", cssFile);

    document.getElementsByTagName("head").item(0).replaceChild(newlink, oldlink);
}

function setDynCSS(url) {
        if (!arguments.length) {
                url = (url = document.cookie.match(/\bdyncss=([^;]*)/)) && url[1];
                if (!url) return '';
        }
        document.getElementById('dyncss').href = url;
        var d = new Date();
        d.setFullYear(d.getFullYear() + 1);
        document.cookie = ['dyncss=', url, ';expires=', d.toGMTString(), ';path=/;'].join('');
        return url;
}

setDynCSS();


// ==============================
// MAKER code

/**
 * global objects placeholder
 */
var global = {
  menu_id:0,
  menu: [],
  value:{},
  manifest:{
	app:"embui",
	appver:0,
	appjsapi:0,
	macid:"000000",
	uiver:0,
	uijsapi:0,
	uiobjects:0,
    lang:"en"
  }
};

/**
 * EmbUI's js api version
 * used to set compatibilty dependency between backend firmware and WebUI js
 */
const ui_jsapi = 7;

/**
 * User application versions - frontend/backend
 * could be overriden with user js code to make EmbUI check code compatibilty
 * checked as integer comparison if not zero
 */
var app_jsapi = 0;

/**
 * An object with loadable UI blocks that could be stored on client's side
 * blocks could be requested to render on-demand from the backend side, so it could
 * save backend from generating block objects every time and sending it to Front-End 
 */
var uiblocks = {};

/**
 * callback for unknown pkg types - Stub function to handle user-defined types messages.
 * Data could be sent from the controller with any 'pkg' types except internal ones used by EmnUI
 * and handled in a user-define js function via reassigning this value
 */
var unknown_pkg_callback = function (msg){
    console.log('Got unknown pkg data, redefine "unknown_pkg_callback" to handle it.', msg);
}


/**
 * A placeholder array for user js-functions that could be executed on button click
 * any user-specific funcs could be appended/removed/replaced to this array later on
 * 
 * UI method to create interactive button is
 * Interface::button_js(const String &id, const String &label, const String &color = "", const T &value = nullptr)
 * where:
 *  'id' is function selector,
 *   'value' is passed value
 */
var customFuncs = {
  // BasicUI class - set system date/time from the browser
  set_time: function (event) {
    var t = new Date();
    var tLocal = new Date(t - t.getTimezoneOffset() * 60 * 1000);
    var isodate = tLocal.toISOString().slice(0, 19);  // chop off chars after ss

    var data = {};
    let value = event.target.value;
    if (value){
      // if there was a param 'value', then paste the date string into doc element with id='value'
      // let's do this via simulating MCU value frame
      console.log("Set specific date:", value)
      data["block"] = [];
      data.block.push({"date" : value});
      var r = render();
      r.value(data);
    } else {
      // if there was no 'value' given, than simply post browser's date string to MCU that triggers time/date setup
      console.log("Set browser's date:", isodate)
      data["sys_datetime"] = isodate;
      ws.send_post("sys_datetime", data);
    }
  }//,
  //func2: function (event) {     console.log('Called func 2'); }
};

/**
 * User Callback for xload() function. Вызывается после завершения загрузки внешних данных, но
 * перед предачей объекта обработчику шаблона. Если коллбек возвращает false, то вызов шаблонизатора не происходит.
 * Может быть перенакрыта пользовательским скриптом для доп обработки загруженных данных
 */
function xload_cb(obj){
//    console.log('redefine xload_cb(obj) func to handle it.', msg);
  return true;
}

/**
 * @brief - Loads JSON objects via http request
 * @param {*} url - URI to load
 * @param {*} ok - callback on success
 * @param {*} err - callback on error
 */
function ajaxload(url, ok, err){
  var xhr = new XMLHttpRequest();
  xhr.overrideMimeType("application/json");
  xhr.responseType = 'json';
  xhr.open('GET', url, true);
  xhr.onreadystatechange = function(){
    if (xhr.readyState == 4 && xhr.status == "200") {
      ok && ok(xhr.response);
    } else if (xhr.status != "200"){
      err && err(xhr.status)
    }
  };
  xhr.send(null);
}

/**
 *   "pkg":"xload" messages are used to make ajax requests for external JSON objects that could be used as data/interface templates
 * используется для загрузки контента/шаблонов из внешних источников - "флеш" контроллера, интернет ресурсы с погодой и т.п.,
 * объекты должны сохранять структуру как если бы они пришли от контроллера. Просмариваются рекурсивно все секции у которых есть ключ 'url',
 * этот урл запрашивается и результат записывается в ключ 'block' текущей секции. Ожидается что по URL будет доступен корректный JSON.
 * Результат передается в рендерер и встраивается в страницу /Vortigont/
 * @param { * } msg - framework content/interface object
 * @returns 
 */
function xload(msg){
    if (!msg.block){
        console.log('Message has no data block!');
        return;
    }

  console.log('Run deepfetch');
  deepfetch(msg.block).then(() => {
     //console.log(msg);
     if (xload_cb(msg)){
      var rdr = this.rdr = render();  // Interface rederer to pass updated objects to
      rdr.make(msg);
     }
  })
}

/**
 * async function to traverse object and fetch all 'url' in sections,
 * this must be done in async mode till the last end, since there could be multiple recursive ajax requests
 * including in sections that were just fetched /Vortigont/
 * @param {*} obj - EmbUI data object
 */
async function deepfetch (obj) {
  for (let i = 0; i < obj.length; i++) if (typeof obj[i] == "object") {
    let element = obj[i];
    if (element.url){
      console.log('xload URL: ' + element.url);
      await new Promise(next=> {
          ajaxload(element.url,
            function(response) {
              element['block'] = response;
              delete element.url;  // удаляем url из элемента т.к. работает рекурсия
              // пробегаемся рекурсивно по новым/вложенным объектам
              if (element.block && typeof element.block == "object") {
                deepfetch(element.block).then(() => {
                  next();
                 })
              } else {
                next();
              }
            },
            function(errstatus) {
              next();
            }
          );
      })
    } else if ( element.block && typeof element.block == "object" ){
      await new Promise(next=> {
        deepfetch(element.block).then(() => {
          next();
        })
      })
    }
  }
}

/**
 * this function recoursevily looks through sections and picks ones with name 'xload'
 * for such sections all html elements with 'url' object key will be side-load with object content into
 * and object named 'block'. Same way as for xload() function.
 * @param {*} msg - object with UI sections
 * @returns 
 */
async function section_xload(msg){
    if (!msg.block) return;
  for (let i = 0; i < msg.block.length; i++){
    let el = msg.block[i];
    if (msg.section == "xload" && el.url){
      // do side load for all elements of the section
      console.log('section xload URL: ', el.url);
      await new Promise(next=> {
        ajaxload(el.url,
          function(response) {
            el['block'] = response;
            next();
          },
          function(errstatus) {
            next();
            //console.log('Error loading external content');
          }
        );
      })
    } else if (el.section){
      // recourse into nested secions
      await new Promise( next => { section_xload(el).then(() => { next(); }) } )
    }
  }
} 

/* Color gradients calculator. Source is from https://gist.github.com/joocer/bf1626d38dd74fef9d9e5fb18fef517c */
function colorGradient(colors, fadeFraction) {
  if (fadeFraction >= 1) {
    return colors[colors.length - 1]
  } else if (fadeFraction <= 0) {
    return colors[0]
  }

  var fade = fadeFraction * (colors.length - 1);
  var interval = Math.trunc(fade);
  fade = fade - interval;

  var color1 = colors[interval];
  var color2 = colors[interval + 1];

  var diffRed = color2.red - color1.red;
  var diffGreen = color2.green - color1.green;
  var diffBlue = color2.blue - color1.blue;

  var gradient = {
    red: parseInt(Math.floor(color1.red + (diffRed * fade)), 10),
    green: parseInt(Math.floor(color1.green + (diffGreen * fade)), 10),
    blue: parseInt(Math.floor(color1.blue + (diffBlue * fade)), 10),
  };

return 'rgb(' + gradient.red + ',' + gradient.green + ',' + gradient.blue + ')';
}

// a simple recursive iterator with callback
function recurseforeachkey(obj, f) {
  for (let key in obj) {
    if (typeof obj[key] === 'object') {
      if (Array.isArray(obj[key])) {
        for (let i = 0; i < obj[key].length; i++) {
          recurseforeachkey(obj[key][i], f);
        }
      } else {
        recurseforeachkey(obj[key], f);
      }
    } else {
      // run callback
      f(key, obj);
    }
  }
}

// recursive block find, look for an obj with matching key,val
function findBlockElement(array, key, value) {
  let o;
  array.some(function iter(a){
      if (a[key] === value) {
          o = a;
          return true;
      }
      return Array.isArray(a.block) && a.block.some(iter);
  });
  return o;
}

/**
 * scan frame object for 'uidata' instruction objects
 * loads/updates objects in uidata container or implaces data into packet from uidata
 * 
 * @param {*} arr a reference to  section.block array
 * @returns 
 */
async function process_uidata(arr){
  if (!(arr instanceof Array))return

  for (let i = 0; i != arr.length; ++i){
    let item = arr[i]
    // skip objects without 'block' key
    if (!(item.block instanceof Array)){
      continue
    } 

    // process uidata sections
    if (item.section == "uidata" ){
      let newblocks = []  // an array for sideloaded blocks
      // scan command objects
      for await (aw of item.block){
        if(aw.action == "xload"){
          // obj can mutate hell knows why while promise it resolved, so make a deep copy here
          let lobj = structuredClone(aw)
          const req = await fetch(lobj.url, {method: 'GET'});
          if (!req.ok){
            console.log("Xload failed:", req.status);
            return;
          } 
          const response = await req.json();
          //console.log("Get responce for:", lobj.url);
          if (lobj.merge){
            if (lobj.src)
              _.merge(_.get(uiblocks, lobj.key), _.get(response, lobj.src))
            else
              _.merge(_.get(uiblocks, lobj.key), response)
            //console.log("Merged key:", lobj.key, lobj.src, aw.key, aw.src);
          } else {
            if (lobj.src)
              _.set(uiblocks, lobj.key, _get(response, lobj.src))
            else
            _.set(uiblocks, lobj.key, response);
            //console.log("Set key:", lobj.key, lobj.src, obj.key, obj.src);
          }
          //console.log("loaded uiobj:", _.get(uiblocks, obj.key));
          //console.log("loaded uiobj:", response, " ver:", response.version);
          // check if loaded data is older then requested from backend
          //console.log("Req ver: ", v.version, " vs loaded ver:", _.get(uiblocks, v.key).version)
          if (lobj.version > _.get(uiblocks, lobj.key).version){
            console.log("Opening update alert msg");
            document.getElementById("update_alert").style.display = "block";
          }
          continue
        }
        // Pick UI object from a previously loaded UI data storage
        if (aw.action == "pick"){
          //console.log("pick obj:", aw.key, _.get(uiblocks, aw.key));
          let ui_obj = structuredClone(_.get(uiblocks, aw.key))  // make a deep-copy to prevent mangling with further processing
          if (ui_obj == undefined){
            // alternate object is available?
            if (aw.alt){
              //console.log("UIData alt:", aw.key, aw.alt);
              ui_obj = aw.alt
            }
            else {
              console.log("UIData is missing:", aw.key);
              continue
            }
          }
          if (Object.keys(ui_obj).length !== 0){
            if (aw.prefix){
              ui_obj.section = aw.prefix + ui_obj.section;
              recurseforeachkey(ui_obj, function(key, object){ if (key === "id"){ object[key] = aw.prefix + obj[key]; } })
            }
            if (aw.suffix){
              ui_obj.section += aw.suffix;
              recurseforeachkey(ui_obj, function(key, object){ if (key === "id"){ object[key] += aw.suffix; } })
            }
            if (aw.newid){
              ui_obj["id"] = aw.newid
            }
            newblocks.push(ui_obj)
          }
          continue
        }
        // Set/update UI object with supplied data
        if (obj.action == "set"){
          _.set(uiblocks, obj.key, obj.data)
          continue
        }
        // Set/update UI object with supplied data
        if (obj.action == "merge"){
          _.merge(_.get(uiblocks, obj.key), obj.data)
          continue
        }
  
      }

      // a function that will replace current section item with uidata items
      function implaceArrayAt(array, idx, arrayToInsert) {
        Array.prototype.splice.apply(array, [idx, 1].concat(arrayToInsert));
        return
      }

      // replace processed section with processed data
      if (newblocks.length){
        implaceArrayAt(arr, i, newblocks)
      } else
        arr.splice(i, 1)  // remove uidata section

        // since array has changed, I must reiterate it all over again
        const chained = await process_uidata(arr)
        // after reiteration no need to continue
      return
    }

    // for non-uidata objects just dive into nested block sections
    if (item.block instanceof Array){
      await process_uidata(item.block)
    }
  }
}


/**
 * recourse object looking for section named "xload",
 * each object inside this section is checked for {"xload":true} pair, if found then an external object is http-loaded via "xload_url" URL and merged into block:[] array
 * @note on load, "xload" key is set to result state of an http load
 * @note on load, the section's value is renamed to the value of "sect_id" key, if "sect_id" is not present, then "xload_{somerandomstring}" is used
 * @param {*} obj - receives an objects referencing section in an "pkg":"interface" frame, or the frame object itself
 */
async function process_XLoadSection(arr){
  if (!(arr instanceof Array)) return
  for await (item of arr){
    // skip objects without 'block' obj
    if (!(item.block instanceof Array)) continue;

    // process xload sections
    if (item.section == "xload" ){
      for await (obj of item.block){
        if (obj.xload && obj.xload_url){
          const req = await fetch(obj.xload_url, {method: 'GET'})
          if (req.ok){
            const resp = await req.json();
            if (resp instanceof Array)
              obj.block.push(...resp)
            else
              obj.block.push(resp)

            obj.xload = true
          } else
            obj.xload = false

          if (item.sect_id){
            item.section = item.sect_id
            delete item.sect_id
          } else
            item.section += Math.round( Math.random() * 1000 )
        }
      }
      continue
    }
    // for non-xload section just dive into nested block sections
    if (item.block instanceof Array)
      await process_XLoadSection(item.block)
  }
  return
}



// template renderer
var render = function(){
  let chkNumeric = function(v){
    // cast empty strings to null
    if (typeof v == 'string' && v == "") return null;
    if(isFinite(v))
      return Number(v);
    else
      return v;
  };

  var tmpl_menu = new mustache(go("#tmpl_menu")[0],{
    on_page: function(d,id) {
      out.menu_change(id);
    }
  }),

  fn_section = {
    on_input: function(d, id){
      var value = this.value, type = this.type;
      if (type == "range") go("#"+id+"-val").html(": " + value);
      if (type == "text" || type == "password") go("#"+id+"-val").html(" ("+value.length+")");
      if (type == "color") go("#"+id+"-val").html(" ("+value+")");
      if (this.id != id){
        custom_hook(this.id, d, id);
      }
    },
    // handle dynamicaly changed elements on a page which should send value to WS server on each change
    on_change: function(d, id, val) {
      let value;

      // check if value has been supplied by templater
      if (val !== undefined){
        value = val;
      } else {
        switch (this.type){
          case 'checkbox':
            value = document.getElementById(id).checked;
            break;
          case 'number':
          case 'select-one':
          case 'range':
            value = chkNumeric(this.value);
            break;
          // cast empty strings to null in inputs
          case 'input':
          case 'textarea':
            value = (typeof this.value == 'string' && this.value == "") ? null : this.value;
          default:
            value = this.value;
        }
      }
      if (this.id != id){
        custom_hook(this.id, d, id);
      }
      let data = {};
      data[id] = value;

      ws.send_post(id, data);
    },
    // show or hide section on a page
    on_showhide: function(d, id) {
      go("#"+id).showhide();
    },
    /**
     *  Process Submited form
     *  'submit' key defines action to be taken by the backend
     */
    on_submit: function(d, id, val) {
      var form = go("#"+id), data = go.formdata(go("input, textarea, select", form));
      //data['submit'] = id;
      if (val !== undefined && typeof val !== 'object') { data[id] = val; }  // submit button _might_ have it's own value
      ws.send_post(id, data);
    },
    // run custom user-js function
    on_js: function(event, callback, arg, id) {
      if (callback in customFuncs){
        //console.log("run user function:", callback, ", arg:", arg, ", id:", id);
        customFuncs[callback](event, arg, id);
      } else
        console.log("User function undefined: ", callback);
    }
  },
  tmpl_section = new mustache(go("#tmpl_section")[0], fn_section),
  tmpl_section_main = new mustache(go("#tmpl_section_main")[0], fn_section),
  tmpl_content = new mustache(go("#tmpl_content")[0], fn_section),
  out = {
    lockhist: false,
    history: function(hist){
      history.pushState({hist:hist}, '', '?'+hist);
    },
    menu_change: function(menu_id){
      global.menu_id = menu_id;
      this.menu();
      go("#main > div").display("none");
      // go("#main #"+menu_id).display("block");
      // var data = {}; data[menu_id] = null
      ws.send_post(menu_id, {});
    },
    menu: function(){
      go("#menu").clear().append(tmpl_menu.parse(global));
    },
    content: function(obj){
      //console.log("Process content:", obj);
      for (i of obj.block){
        go("#"+i.id).replace(tmpl_content.parse(i));
      }
    },
    section: function(obj){
      if (obj.main) {
        go("#main > section").remove();
        go("#main").append(tmpl_section_main.parse(obj));
        if (!out.lockhist) out.history(obj.section);
      } else {
        if ( Object.keys(go("#"+obj.section)).length === 0 && !obj.replace ){
          go("#main").append(tmpl_section_main.parse(obj));
        } else {
          console.log("replacing section:", obj.section)
          go("#"+obj.section).replace(tmpl_section.parse(obj));
        }
      }
    },
    // process "pkg":"interface" messages and render template
    make: async function(obj){
      if (!obj.block) return;
      let frame = obj.block;

      // deep iterate and process "uidata" sections
      const ui_processed = await process_uidata(frame);
      const xload_processed = await process_XLoadSection(frame);
      console.log("Processed packet:", obj);

      // go through sections and render it according to type of data
      frame.forEach(function(v, idx, frame){
        if (v.section == "manifest"){
          for (item of v.block){
            _.merge(global, "manifest", item)
          }
          if (global.manifest.app && global.manifest.mc)
            document.title = global.manifest.app + " - " + global.manifest.mc;

    		  if (global.manifest.uijsapi > ui_jsapi || global.manifest.appjsapi > app_jsapi || (uiblocks.sys.version != undefined && global.manifest.uiobjects > uiblocks.sys.version))
            document.getElementById("update_alert").style.display = "block";
          return;
        }

        if (v.section == "menu"){
          global.menu =  v.block;
          if (!global.menu_id) global.menu_id = global.menu[0].value
          this.menu();
          return;
        }

        if (v.section == "content") {
          this.content(v)
          return;
        }

        // callback section contains actions that UI should request back from MCU
        if (v.section == "callback") {
          for (item of v.block){
            let data = {};
            if (item.data)
              data = item.data
            ws.send_post(item.action, data);
          }
          return;
        }

        // section with value - process as value frame
        if (v.section == "value") {
          this.value(v)
          return;
        }


        // look for nested xload sections and await for side-load, if found
        //section_xload(v).then( () => { this.section(v); } );
        this.section(v)
      }, this)  // need this to refer to .menu and .section inside forEach
      out.lockhist = false;
    },

    // processing packets with values - "pkg":"value"
    // блок разбирается на объекты по id и их value применяются к элементам шаблона на html странице
    value: function(obj){
      let frame = obj.block;
      if (!obj.block) return;

      /*
        Find DOM object with id 'key' and sets it's 'value' property to 'val'.
        If 'html' is set to 'true', than values applied as html-text value,
        i.e. template tags visible on the page  ( <span>{{value}}</span> )
        otherwise value applies to an html element's attribute ( <input type="range" value="{{value}}" )
      */
      function setValue(key, val, html = false){
        if (val == null || typeof val == "object") return;  // skip undef/null or (empty) objects
        let el = go("#"+key);
        if (!el.length) return;
        if (html === true ){ el.html(val); return; }

        // checkbox state
        if (el[0].type == "checkbox") {
          // allow multiple types of TRUE value for checkboxes
          el[0].checked = (val == true  ||  val == 1 || val == "1" || val == "true" );
          return;
        }

        // update progressbar's
        if (el[0].className == "progressab") {
          // value of '0' is endless 'in-progress'
          if (val == 0){
            el[0].style.width = "100%";
            el[0].innerText = "...";
            el[0].style.backgroundColor = 'rgb(10,0,0)';
            return;
          }

          el[0].style.width = val+"%";
          el[0].innerText = val+"% Complete";

          var color1 = { red: 200, green: 0, blue: 0 };
          var color2 = { red: 220, green: 204, blue: 0 };
          var color3 = { red: 0, green: 200, blue: 0 };
          var color4 = { red: 0, green: 0, blue: 240 };
          var bar_color = colorGradient([ color1, color2, color3, color4 ], val/100 ); // expect percents here
          el[0].style.backgroundColor = bar_color;
          //console.log("progress upd ", el[0], " color: ", bar_color);
          return;
        }

        if (el[0].type == "range") { go("#"+el[0].id+"-val").html(": "+val); }    // update span with range's label

        //console.log("Element is: ", el[0], " class is: ", el[0].className);
        el[0].value = val;
      }

      for (var i = 0; i < frame.length; i++) if (typeof frame[i] == "object") {
        /* check if the object contains just an object with key:value pairs (comes from echo-back packets)
          { "id": "someid", "value": "somevalue", "html": true }
        */
        if ('id' in frame[i] && 'value' in frame[i]){
          setValue(frame[i].id, frame[i].value, frame[i].html);
        } else {
          // else it's an object with k:v pairs
          for(let k in frame[i]) {
            setValue(k, frame[i][k]);
          }
        }
      }
    }
  };
  return out;
};



window.addEventListener("load", async function(ev){
  var rdr = this.rdr = render();
  var ws = this.ws = wbs("ws://"+location.host+"/ws");

  ws.oninterface = function(msg) { rdr.make(msg) }

  // run custom js function in window context
  ws.onjscall = function(msg) {
    if ( msg.jsfunc in customFuncs){
      try {   console.log("JSCall: ", msg.jsfunc);
        customFuncs[msg.jsfunc](msg)
        //window[msg.jsfunc](msg);
      } catch(e){ console.log('Error on calling function:'+msg.function, e); }
    };
  }

  ws.onvalue = function(msg){ rdr.value(msg) }
  ws.onclose = ws.onerror = function(){ ws.connect() }

  // "pkg":"xload" messages are used to make ajax requests for external JSON objects that could be used as data/interface templates
  ws.onxload = function(mgs){ xload(mgs) }

  // any Packets with unknown "pkg":"type" are handled here via user-redefinable callback
  ws.onUnknown = function(msg){ unknown_pkg_callback(msg) }

  // load sys UI objects
  let response = await fetch("/js/ui_embui.json", {method: 'GET'});
  if (response.ok){
    response = await response.json();
    uiblocks['sys'] = response;
    //console.log("loaded obj:", uiblocks.sys);
  }
  // preload i18n
  //let i18n = await fetch("/js/ui_embui.i18n.json", {method: 'GET'});
  //let lang = await fetch("/js/ui_embui.lang.json", {method: 'GET'});

  ws.connect();

  var active = false, layout =  go("#layout");
  go("#menuLink").bind("click", function(){
    active = !active;
    if (active) layout.addClass("active");
    else layout.removeClass("active");
    return false;
  });
  go("#layout, #menu, #main").bind("click", function(){
    active = false;
    if (layout.contClass("active")[0]) {
      layout.removeClass("active");
      return false;
    }
  });
}.bind(window)
);

window.addEventListener("popstate", function(e){
  if (e = e.state && e.state.hist) {
    rdr.lockhist = true;
    //var data = {}; data[e] = null;
    ws.send_post(e, {});
  }
});
